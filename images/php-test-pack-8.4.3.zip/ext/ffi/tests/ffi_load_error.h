#define FFI_LIB "./donotexist.so"
