#include <stdio.h>

int main()
{
	printf("pwnd!\n");
	return 0;
}
